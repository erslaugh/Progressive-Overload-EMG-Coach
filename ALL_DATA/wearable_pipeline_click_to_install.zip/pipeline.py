from __future__ import annotations

import json
import math
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from scipy import signal
from scipy.io import wavfile


@dataclass
class TrialLabel:
    name: str
    subject_name: str
    condition: str
    weight_lb: float
    completed_reps: int
    end_rir: Optional[float]
    controlled_failure: int
    poor_form_reps: int
    emg_file: str
    imu_file: Optional[str] = None
    use_for_form_reference: bool = False
    use_for_fatigue_reference: bool = False
    use_for_emg_calibration: bool = False
    use_for_static_hold: bool = False


def _to_mono_float(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x)
    if x.ndim > 1:
        x = x.mean(axis=1)
    if np.issubdtype(x.dtype, np.integer):
        info = np.iinfo(x.dtype)
        scale = max(abs(info.min), abs(info.max))
        return x.astype(float) / float(scale)
    return x.astype(float)


def load_emg_wav(path: str | Path):
    fs, x = wavfile.read(path)
    x = _to_mono_float(x)
    return float(fs), x


def preprocess_emg(x: np.ndarray, fs: float) -> np.ndarray:
    x = np.asarray(x, float)
    x = x - np.nanmedian(x)
    nyq = fs / 2.0
    high = min(450.0, nyq * 0.90)
    if high > 25:
        sos = signal.butter(4, [20.0, high], btype='bandpass', fs=fs, output='sos')
        x = signal.sosfiltfilt(sos, x)
    # 60 Hz notch where supported.
    if fs > 180:
        b, a = signal.iirnotch(60.0, 30.0, fs)
        x = signal.filtfilt(b, a, x)
    return x


def moving_rms(x: np.ndarray, fs: float, window_ms: float = 100.0) -> np.ndarray:
    n = max(3, int(round(fs * window_ms / 1000.0)))
    kernel = np.ones(n, dtype=float) / n
    return np.sqrt(np.maximum(np.convolve(x * x, kernel, mode='same'), 0.0))


def emg_features(path: str | Path) -> dict:
    fs, raw = load_emg_wav(path)
    filt = preprocess_emg(raw, fs)
    rms = moving_rms(filt, fs)
    eps = 1e-12
    return {
        'fs_hz': fs,
        'duration_s': len(raw) / fs,
        'rms_median': float(np.nanmedian(rms)),
        'rms_mean': float(np.nanmean(rms)),
        'rms_p90': float(np.nanpercentile(rms, 90)),
        'rms_p95': float(np.nanpercentile(rms, 95)),
        'rms_p99': float(np.nanpercentile(rms, 99)),
        'rms_max': float(np.nanmax(rms)),
        'rms_dynamic_ratio': float(np.nanpercentile(rms, 95) / max(np.nanmedian(rms), eps)),
    }


def load_phyphox_zip(path: str | Path):
    with zipfile.ZipFile(path, 'r') as z:
        gyro = pd.read_csv(z.open('Gyroscope.csv'))
        accel = pd.read_csv(z.open('Accelerometer.csv'))
    return gyro, accel


def _estimate_fs(t: np.ndarray) -> float:
    t = np.asarray(t, float)
    dt = np.diff(t)
    dt = dt[np.isfinite(dt) & (dt > 0)]
    if len(dt) == 0:
        return float('nan')
    return float(1.0 / np.median(dt))


def _smooth(x: np.ndarray, fs: float, seconds: float = 0.12) -> np.ndarray:
    n = max(1, int(round(fs * seconds))) if np.isfinite(fs) else 5
    if n <= 1:
        return x
    return np.convolve(x, np.ones(n) / n, mode='same')


def imu_features(path: str | Path, expected_reps: Optional[int] = None) -> dict:
    gyro, accel = load_phyphox_zip(path)
    tg = gyro['Time (s)'].to_numpy(float)
    ta = accel['Time (s)'].to_numpy(float)
    gxyz = gyro[['X (rad/s)', 'Y (rad/s)', 'Z (rad/s)']].to_numpy(float)
    axyz = accel[['X (m/s^2)', 'Y (m/s^2)', 'Z (m/s^2)']].to_numpy(float)
    gfs = _estimate_fs(tg)
    afs = _estimate_fs(ta)

    # Use the most active gyro axis for rep timing; vector magnitude for orientation-independent form metrics.
    axis_std = np.nanstd(gxyz, axis=0)
    dom_idx = int(np.nanargmax(axis_std))
    dom = gxyz[:, dom_idx]
    gmag = np.linalg.norm(gxyz, axis=1)
    amag = np.linalg.norm(axyz, axis=1)

    dom_s = _smooth(dom, gfs, 0.10)
    abs_dom_s = _smooth(np.abs(dom_s), gfs, 0.08)

    # Rep peak detection. If expected reps are known, tune prominence to get close without forcing counts.
    min_distance = max(1, int(round((gfs if np.isfinite(gfs) else 100) * 0.55)))
    prominence = max(np.nanstd(abs_dom_s) * 0.45, np.nanpercentile(abs_dom_s, 70) * 0.10)
    peaks, props = signal.find_peaks(abs_dom_s, distance=min_distance, prominence=prominence)
    if expected_reps and expected_reps > 0 and len(peaks) > expected_reps * 1.2:
        # Keep strongest peaks if excessive noise created extras.
        strengths = props.get('prominences', abs_dom_s[peaks])
        keep = np.argsort(strengths)[-expected_reps:]
        peaks = np.sort(peaks[keep])

    if len(peaks) >= 2:
        rep_intervals = np.diff(tg[peaks])
        rep_period_mean = float(np.nanmean(rep_intervals))
        rep_period_cv = float(np.nanstd(rep_intervals) / max(np.nanmean(rep_intervals), 1e-9))
    else:
        rep_period_mean = float('nan')
        rep_period_cv = float('nan')

    # Acceleration jerk magnitude from numerical derivative.
    if len(ta) >= 3:
        jerk = np.gradient(axyz, ta, axis=0)
        jerk_mag = np.linalg.norm(jerk, axis=1)
    else:
        jerk_mag = np.array([np.nan])

    # Angular acceleration/jerk analog from gyro derivative.
    if len(tg) >= 3:
        angular_accel = np.gradient(gxyz, tg, axis=0)
        angular_accel_mag = np.linalg.norm(angular_accel, axis=1)
    else:
        angular_accel_mag = np.array([np.nan])

    peak_vals = abs_dom_s[peaks] if len(peaks) else np.array([], float)
    velocity_loss_pct = float('nan')
    if len(peak_vals) >= 4:
        k = max(1, min(3, len(peak_vals) // 3))
        early = float(np.mean(peak_vals[:k]))
        late = float(np.mean(peak_vals[-k:]))
        if early > 1e-9:
            velocity_loss_pct = float((early - late) / early * 100.0)

    return {
        'gyro_fs_hz': gfs,
        'accel_fs_hz': afs,
        'duration_s': float(max(tg[-1] - tg[0], ta[-1] - ta[0])),
        'dominant_gyro_axis': ['X', 'Y', 'Z'][dom_idx],
        'detected_reps': int(len(peaks)),
        'rep_period_mean_s': rep_period_mean,
        'rep_period_cv': rep_period_cv,
        'gyro_mag_mean': float(np.nanmean(gmag)),
        'gyro_mag_p95': float(np.nanpercentile(gmag, 95)),
        'gyro_mag_std': float(np.nanstd(gmag)),
        'accel_mag_std': float(np.nanstd(amag)),
        'jerk_p95': float(np.nanpercentile(jerk_mag, 95)),
        'jerk_rms': float(np.sqrt(np.nanmean(jerk_mag ** 2))),
        'angular_accel_p95': float(np.nanpercentile(angular_accel_mag, 95)),
        'peak_angular_speed_mean': float(np.nanmean(peak_vals)) if len(peak_vals) else float('nan'),
        'peak_angular_speed_cv': float(np.nanstd(peak_vals) / max(np.nanmean(peak_vals), 1e-9)) if len(peak_vals) else float('nan'),
        'velocity_loss_pct': velocity_loss_pct,
    }


def _finite_feature_vector(feats: dict, keys: list[str]) -> np.ndarray:
    vals = []
    for k in keys:
        v = feats.get(k, np.nan)
        vals.append(float(v) if np.isfinite(v) else 0.0)
    return np.asarray(vals, float)


FORM_KEYS = [
    'jerk_p95', 'jerk_rms', 'angular_accel_p95', 'rep_period_cv',
    'peak_angular_speed_cv', 'accel_mag_std', 'gyro_mag_std'
]


def form_score(imu: dict, clean_ref: dict, jerky_ref: dict) -> tuple[float, str]:
    x = _finite_feature_vector(imu, FORM_KEYS)
    c = _finite_feature_vector(clean_ref, FORM_KEYS)
    j = _finite_feature_vector(jerky_ref, FORM_KEYS)
    scale = np.maximum(np.maximum(np.abs(c), np.abs(j)), 1e-6)
    dc = float(np.linalg.norm((x - c) / scale))
    dj = float(np.linalg.norm((x - j) / scale))
    score = dc / max(dc + dj, 1e-9)  # 0 clean-like, 1 jerky-like
    label = 'poor-form-like' if score >= 0.60 else ('borderline' if score >= 0.45 else 'clean-like')
    return float(score), label


def build_profile(data_dir: str | Path, manifest_path: str | Path, output_path: str | Path) -> dict:
    data_dir = Path(data_dir)
    manifest = json.loads(Path(manifest_path).read_text())
    trials = [TrialLabel(**t) for t in manifest['trials']]
    subject = manifest['subject_name']

    profile = {
        'subject_name': subject,
        'profile_version': 1,
        'notes': 'Current profile uses RIR 5 and RIR 3 fatigue anchors. Add RIR 0-1/1-2 fatigue trial later for stronger stop calibration.',
        'trials': {},
    }

    clean_ref = None
    jerky_ref = None
    fatigue_points = []
    emg_ref = None
    static_ref = None

    for t in trials:
        emg = emg_features(data_dir / t.emg_file)
        imu = None
        if t.imu_file:
            imu = imu_features(data_dir / t.imu_file, t.completed_reps if t.completed_reps > 0 else None)
        profile['trials'][t.name] = {'label': asdict(t), 'emg': emg, 'imu': imu}

        if t.use_for_emg_calibration:
            emg_ref = emg
        if t.use_for_static_hold:
            static_ref = emg
        if t.use_for_form_reference and imu:
            if t.poor_form_reps == 0:
                clean_ref = imu
            else:
                jerky_ref = imu
        if t.use_for_fatigue_reference and t.end_rir is not None and imu:
            fatigue_points.append({
                'rir': float(t.end_rir),
                'weight_lb': float(t.weight_lb),
                'emg_p95': emg['rms_p95'],
                'velocity_loss_pct': imu['velocity_loss_pct'],
                'peak_angular_speed_mean': imu['peak_angular_speed_mean'],
            })

    profile['emg_calibration'] = {
        'hard_squeeze_rms_p95': emg_ref['rms_p95'] if emg_ref else None,
        'hard_squeeze_rms_p99': emg_ref['rms_p99'] if emg_ref else None,
        'static_hold_rms_p95': static_ref['rms_p95'] if static_ref else None,
    }
    profile['form_reference'] = {'clean': clean_ref, 'jerky': jerky_ref, 'feature_keys': FORM_KEYS}
    profile['fatigue_reference'] = sorted(fatigue_points, key=lambda d: d['rir'], reverse=True)

    Path(output_path).write_text(json.dumps(profile, indent=2, allow_nan=True))
    return profile


def _relative_emg(emg: dict, profile: dict) -> float:
    ref = profile.get('emg_calibration', {}).get('hard_squeeze_rms_p95')
    if ref is None or not np.isfinite(ref) or ref <= 0:
        return float('nan')
    return float(emg['rms_p95'] / ref)


def estimate_rir_from_current_anchors(emg: dict, imu: dict, profile: dict) -> Optional[float]:
    """Rough interpolation using only the currently available RIR 5 and RIR 3 anchors.

    This intentionally refuses to extrapolate below RIR 2 because the near-fatigue anchor has not
    yet been collected. It is a hackathon calibration, not a clinical model.
    """
    pts = profile.get('fatigue_reference', [])
    pts = [p for p in pts if np.isfinite(p.get('rir', np.nan))]
    if len(pts) < 2:
        return None

    # Composite fatigue indicator: normalized EMG + positive velocity loss.
    def indicator(p):
        vl = p.get('velocity_loss_pct', np.nan)
        vl = 0.0 if not np.isfinite(vl) else max(0.0, vl) / 100.0
        return float(p['emg_p95']) * (1.0 + vl)

    xs = np.array([indicator(p) for p in pts], float)
    ys = np.array([p['rir'] for p in pts], float)
    vl = imu.get('velocity_loss_pct', np.nan)
    vl = 0.0 if not np.isfinite(vl) else max(0.0, vl) / 100.0
    x = float(emg['rms_p95']) * (1.0 + vl)

    # Fit line on the two/current anchors; clamp to supported range until hard set exists.
    if np.ptp(xs) < 1e-12:
        return float(np.mean(ys))
    coef = np.polyfit(xs, ys, 1)
    pred = float(np.polyval(coef, x))
    return float(np.clip(pred, 2.0, 6.0))


def analyze_run(
    subject_name: str,
    weight_lb: float,
    emg_path: str | Path,
    imu_zip_path: str | Path,
    profile_path: str | Path,
    expected_reps: Optional[int] = None,
) -> dict:
    profile = json.loads(Path(profile_path).read_text())
    emg = emg_features(emg_path)
    imu = imu_features(imu_zip_path, expected_reps)

    clean_ref = profile.get('form_reference', {}).get('clean')
    jerky_ref = profile.get('form_reference', {}).get('jerky')
    if clean_ref and jerky_ref:
        fscore, flabel = form_score(imu, clean_ref, jerky_ref)
    else:
        fscore, flabel = float('nan'), 'unavailable'

    rir_est = estimate_rir_from_current_anchors(emg, imu, profile)
    rel_emg = _relative_emg(emg, profile)
    vel_loss = imu.get('velocity_loss_pct', np.nan)

    # Conservative recommendation logic while no near-fatigue trial exists.
    # Poor form overrides progressive-overload suggestions.
    if np.isfinite(fscore) and fscore >= 0.60:
        recommendation = 'STOP'
        reason = 'Movement is substantially closer to Ellie\'s jerky/poor-form reference than her clean-form reference.'
        confidence = 'medium'
    elif rir_est is not None and rir_est >= 4.5:
        recommendation = 'MORE WEIGHT'
        reason = f'Current signal pattern looks relatively easy (estimated RIR about {rir_est:.1f}) and form is not poor-form-like.'
        confidence = 'low-medium'
    elif rir_est is not None and rir_est >= 2.5:
        recommendation = 'MORE REPS'
        reason = f'Current signal pattern is between Ellie\'s easy and moderate anchors (estimated RIR about {rir_est:.1f}).'
        confidence = 'low-medium'
    else:
        recommendation = 'MORE REPS'
        reason = 'Near-fatigue calibration has not been added yet, so the pipeline will not infer a fatigue-based STOP from EMG/velocity alone.'
        confidence = 'low'

    return {
        'subject_name': subject_name,
        'weight_lb': float(weight_lb),
        'recommendation': recommendation,
        'confidence': confidence,
        'reason': reason,
        'estimated_rir': rir_est,
        'relative_emg_to_hard_squeeze': rel_emg,
        'form_score_0_clean_1_jerky': fscore,
        'form_label': flabel,
        'detected_reps': imu.get('detected_reps'),
        'velocity_loss_pct': vel_loss,
        'emg': emg,
        'imu': imu,
        'calibration_status': {
            'hard_squeeze': bool(profile.get('emg_calibration', {}).get('hard_squeeze_rms_p95')),
            'static_hold': bool(profile.get('emg_calibration', {}).get('static_hold_rms_p95')),
            'clean_form_reference': clean_ref is not None,
            'jerky_form_reference': jerky_ref is not None,
            'fatigue_anchor_rir5': any(abs(p.get('rir', -99) - 5) < .2 for p in profile.get('fatigue_reference', [])),
            'fatigue_anchor_rir3': any(abs(p.get('rir', -99) - 3) < .2 for p in profile.get('fatigue_reference', [])),
            'near_fatigue_anchor': any(p.get('rir', 99) <= 2 for p in profile.get('fatigue_reference', [])),
        },
        'warning': 'Prototype personalized heuristic. Do not use as a medical/safety device or to push through pain, dizziness, or unsafe form.',
    }
