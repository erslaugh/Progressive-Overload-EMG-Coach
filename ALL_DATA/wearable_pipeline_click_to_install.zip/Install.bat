@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Wearable Pipeline Installer

 echo.
 echo ===============================================
 echo   Wearable Progressive Overload Pipeline
 echo   One-click setup for Windows
 echo ===============================================
 echo.

set "PYEXE="
where py >nul 2>nul
if not errorlevel 1 set "PYEXE=py -3"

if not defined PYEXE (
    where python >nul 2>nul
    if not errorlevel 1 set "PYEXE=python"
)

if not defined PYEXE (
    echo Python was not found. Trying to install Python 3.12 with Windows Package Manager...
    echo.
    where winget >nul 2>nul
    if errorlevel 1 goto :NO_PYTHON

    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    if errorlevel 1 goto :NO_PYTHON

    if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
        set "PYEXE=%LocalAppData%\Programs\Python\Python312\python.exe"
    ) else (
        where python >nul 2>nul
        if not errorlevel 1 set "PYEXE=python"
    )
)

if not defined PYEXE goto :NO_PYTHON

echo [1/4] Creating a private Python environment...
if not exist ".venv\Scripts\python.exe" (
    %PYEXE% -m venv .venv
    if errorlevel 1 goto :FAILED
)

set "VPY=%CD%\.venv\Scripts\python.exe"

echo [2/4] Installing required packages...
"%VPY%" -m pip install --upgrade pip
if errorlevel 1 goto :FAILED
"%VPY%" -m pip install -r requirements.txt
if errorlevel 1 goto :FAILED

echo [3/4] Building Ellie's calibration profile...
"%VPY%" build_profile.py
if errorlevel 1 goto :FAILED

echo [4/4] Setup complete.
echo.
echo Opening the pipeline now...
start "" "%CD%\.venv\Scripts\pythonw.exe" "%CD%\app.py"
exit /b 0

:NO_PYTHON
echo.
echo ------------------------------------------------
echo Python could not be installed automatically.
echo Please install Python 3.10 or newer from python.org,
echo then double-click Install.bat again.
echo ------------------------------------------------
echo.
pause
exit /b 1

:FAILED
echo.
echo ------------------------------------------------
echo Installation stopped because a step failed.
echo Leave this window open and send the error text to ChatGPT.
echo ------------------------------------------------
echo.
pause
exit /b 1
