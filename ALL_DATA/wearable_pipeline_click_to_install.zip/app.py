from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox
from tkinter import ttk

from pipeline import analyze_run, build_profile

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / 'ellie_profile.json'
MANIFEST = ROOT / 'manifest.json'
DATA = ROOT / 'data'


def ensure_profile():
    if not PROFILE.exists():
        build_profile(DATA, MANIFEST, PROFILE)


class WearableApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Progressive Overload Wearable Analyzer')
        self.geometry('760x650')
        self.minsize(700, 600)
        ensure_profile()

        self.name_var = tk.StringVar(value='Ellie')
        self.weight_var = tk.StringVar(value='15')
        self.reps_var = tk.StringVar(value='')
        self.emg_var = tk.StringVar()
        self.imu_var = tk.StringVar()

        self._build()

    def _build(self):
        outer = ttk.Frame(self, padding=24)
        outer.pack(fill='both', expand=True)

        ttk.Label(outer, text='Wearable Progressive Overload Analyzer', font=('Segoe UI', 20, 'bold')).pack(anchor='w')
        ttk.Label(outer, text='Personalized to the current Ellie calibration dataset', font=('Segoe UI', 10)).pack(anchor='w', pady=(0,18))

        form = ttk.Frame(outer)
        form.pack(fill='x')
        form.columnconfigure(1, weight=1)

        fields = [('Name', self.name_var), ('Weight (lb)', self.weight_var), ('Expected reps (optional)', self.reps_var)]
        for r, (label, var) in enumerate(fields):
            ttk.Label(form, text=label).grid(row=r, column=0, sticky='w', padx=(0,12), pady=6)
            ttk.Entry(form, textvariable=var).grid(row=r, column=1, sticky='ew', pady=6)

        ttk.Label(form, text='EMG WAV').grid(row=3, column=0, sticky='w', padx=(0,12), pady=6)
        ttk.Entry(form, textvariable=self.emg_var).grid(row=3, column=1, sticky='ew', pady=6)
        ttk.Button(form, text='Choose WAV', command=self.pick_emg).grid(row=3, column=2, padx=(8,0))

        ttk.Label(form, text='phyphox ZIP').grid(row=4, column=0, sticky='w', padx=(0,12), pady=6)
        ttk.Entry(form, textvariable=self.imu_var).grid(row=4, column=1, sticky='ew', pady=6)
        ttk.Button(form, text='Choose ZIP', command=self.pick_imu).grid(row=4, column=2, padx=(8,0))

        ttk.Button(outer, text='RUN ANALYSIS', command=self.run_analysis).pack(fill='x', pady=(22,16), ipady=12)

        self.card = tk.Frame(outer, bg='#e5e7eb', bd=0, highlightthickness=0)
        self.card.pack(fill='x', pady=(0,12))
        self.result_label = tk.Label(self.card, text='Select the newest WAV + phyphox ZIP', font=('Segoe UI', 24, 'bold'), bg='#e5e7eb', fg='#111827', pady=22)
        self.result_label.pack(fill='x')

        self.summary = tk.Text(outer, height=15, wrap='word', font=('Consolas', 10), relief='flat')
        self.summary.pack(fill='both', expand=True)
        self.summary.insert('1.0', 'Current calibration: hard squeezes + 15-lb static hold + clean/jerky references + RIR 5 + RIR 3.\nNear-fatigue anchor will be added later.')
        self.summary.configure(state='disabled')

    def pick_emg(self):
        f = filedialog.askopenfilename(title='Select EMG WAV', filetypes=[('WAV files','*.wav')])
        if f: self.emg_var.set(f)

    def pick_imu(self):
        f = filedialog.askopenfilename(title='Select phyphox ZIP', filetypes=[('ZIP files','*.zip')])
        if f: self.imu_var.set(f)

    def run_analysis(self):
        try:
            weight = float(self.weight_var.get())
            reps = int(self.reps_var.get()) if self.reps_var.get().strip() else None
            if not self.emg_var.get() or not self.imu_var.get():
                raise ValueError('Choose both an EMG WAV and a phyphox ZIP.')
            result = analyze_run(self.name_var.get().strip() or 'Ellie', weight, self.emg_var.get(), self.imu_var.get(), PROFILE, reps)
        except Exception as e:
            messagebox.showerror('Analysis error', str(e))
            return

        rec = result['recommendation']
        if rec == 'MORE WEIGHT':
            bg, fg = '#16a34a', 'white'
        elif rec == 'STOP':
            bg, fg = '#dc2626', 'white'
        else:
            bg, fg = '#f59e0b', '#111827'
        self.card.configure(bg=bg)
        self.result_label.configure(text=rec, bg=bg, fg=fg)

        rir = result['estimated_rir']
        rir_txt = 'not available' if rir is None else f'{rir:.2f}'
        vl = result['velocity_loss_pct']
        vl_txt = 'n/a' if vl is None or not isinstance(vl, (int,float)) else (f'{vl:.1f}%' if vl == vl else 'n/a')
        fs = result['form_score_0_clean_1_jerky']
        fs_txt = 'n/a' if fs != fs else f'{fs:.2f}'
        lines = [
            f"Name: {result['subject_name']}",
            f"Weight: {result['weight_lb']:.2f} lb",
            f"Recommendation: {rec} ({result['confidence']} confidence)",
            f"Reason: {result['reason']}",
            '',
            f"Estimated RIR: {rir_txt}",
            f"Detected reps: {result['detected_reps']}",
            f"Velocity loss: {vl_txt}",
            f"Form: {result['form_label']} (0=clean, 1=jerky score: {fs_txt})",
            f"EMG / hard-squeeze reference: {result['relative_emg_to_hard_squeeze']:.3f}",
            '',
            'Calibration status:',
            json.dumps(result['calibration_status'], indent=2),
            '',
            result['warning'],
        ]
        self.summary.configure(state='normal')
        self.summary.delete('1.0','end')
        self.summary.insert('1.0','\n'.join(lines))
        self.summary.configure(state='disabled')


if __name__ == '__main__':
    WearableApp().mainloop()
