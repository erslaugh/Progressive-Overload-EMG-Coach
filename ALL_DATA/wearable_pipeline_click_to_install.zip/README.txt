UPDATED WEARABLE PIPELINE — ELLIE PROFILE

WINDOWS QUICK START
1. Unzip the whole folder.
2. Double-click Install.bat once.
3. After that, double-click Run Pipeline.bat whenever you want to use it.

Install.bat automatically creates a private Python environment, installs requirements, rebuilds Ellie's profile, and launches the dashboard. If Python is missing and Windows Package Manager is available, it will attempt to install Python 3.12 automatically.

CURRENT PERSONAL CALIBRATION DATA
- 3 Calibration.wav -> 3 hard 2–3 s isometric biceps squeezes (EMG reference)
- Holding Weight.wav + 10 sec hold...zip -> 15 lb static hold reference
- 20 Clean Form.wav + Good form...zip -> clean form IMU reference
- 20 Jerky Form.wav + bad form...zip -> poor/jerky form IMU reference
- Easy 5 Reps.wav + 5 RIR...zip -> 15 lb, 5 reps, end RIR 5
- Moderate 8 Reps.wav + actual moderate...zip -> 15 lb, 8 reps, end RIR 3

NOT CURRENTLY USED
- moderate 2026-08-22 19-06-23.zip (older unmatched IMU recording)

WHEN THE FATIGUE SET IS READY
Add it to manifest.json as another trial with use_for_fatigue_reference=true and its true end_rir.
Then run: python build_profile.py
No pipeline redesign is needed.

IMPORTANT LIMITATION
Until a near-fatigue RIR 0–2 reference exists, the pipeline intentionally does not issue STOP based only on fatigue extrapolation. It can still issue STOP when movement becomes strongly poor-form-like. This avoids pretending the current RIR 5 + RIR 3 data establish a reliable failure threshold.

This is a prototype/hackathon decision-support system, not a medical or safety device.
