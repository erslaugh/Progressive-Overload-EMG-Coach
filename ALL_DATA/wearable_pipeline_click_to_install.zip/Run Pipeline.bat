@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\pythonw.exe" (
    echo The pipeline has not been installed yet.
    echo Starting Install.bat...
    call "%~dp0Install.bat"
    exit /b
)

start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0app.py"
