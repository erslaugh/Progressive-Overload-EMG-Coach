from pathlib import Path
from pipeline import build_profile

ROOT = Path(__file__).resolve().parent
profile = build_profile(ROOT / 'data', ROOT / 'manifest.json', ROOT / 'ellie_profile.json')
print('Built profile:', ROOT / 'ellie_profile.json')
print('Subject:', profile['subject_name'])
print('Fatigue anchors:', [(p['rir'], p['weight_lb']) for p in profile['fatigue_reference']])
